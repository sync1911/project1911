const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const openai = require('openai');
const dotenv = require('dotenv');

dotenv.config();
openai.apiKey = process.env.OPENAI_API_KEY;

const app = express();

app.use(cors());
app.use(bodyParser.json());

async function sendMessageToGPT3(prompt) {
  try {
    const response = await openai.Completion.create({
      engine: 'text-davinci-002',
      prompt: prompt,
      max_tokens: 150,
      n: 1,
      stop: null,
      temperature: 0.7,
    });

    return response.choices[0].text.trim();
  } catch (error) {
    console.error('Error while sending message to GPT-3:', error);
    return 'Error processing your message. Please try again.';
  }
}

app.post('/chat', async (req, res) => {
  const userInput = req.body.message;
  const prompt = `User: ${userInput}\nAssistant: `;
  const gpt3Response = await sendMessageToGPT3(prompt);
  res.json({ message: gpt3Response });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
