window.fbAsyncInit = function () {
  FB.init({
      appId: '3492037904448911',
      cookie: true,
      xfbml: true,
      version: 'v16.0',
  });

  FB.AppEvents.logPageView();
};

function facebookLogin() {
  FB.login(
    function (response) {
      if (response.status === "connected") {
        console.log("Logged in successfully");
        fetchFacebookAdsData();
      } else {
        console.log("User cancelled login or did not fully authorize.");
      }
    },
    { scope: "ads_management,ads_read" }
  );
}



function fetchFacebookAdsData() {
  FB.api('/me/adaccounts', 'GET', {fields: 'account_id,name'}, function (response) {
    if (response && !response.error) {
      displayAdAccounts(response.data);
    } else {
      console.error(response.error);
      displayError('There was an error while fetching ad accounts. Please try another ad account. This one might be restricted.');
    }
  });
}


function displayAdAccounts(adAccounts) {
  const adAccountsList = document.getElementById('adAccountsList');

  adAccounts.forEach((adAccount) => {
    const listItem = document.createElement('li');
    listItem.textContent = `${adAccount.name} (${adAccount.account_id})`;

    // Add click event listener to select the ad account
    listItem.addEventListener('click', () => {
      // Fetch the data for the selected ad account
      fetchAdAccountData(adAccount.account_id);
      closeModal();
    });

    adAccountsList.appendChild(listItem);
  });

  // Display the modal
  openModal();
}

function openModal() {
  const modal = document.getElementById('adAccountModal');
  modal.style.display = 'block';

  const closeButton = document.querySelector('.close');
  closeButton.addEventListener('click', closeModal);
}

function closeModal() {
  const modal = document.getElementById('adAccountModal');
  modal.style.display = 'none';
}



function processData(adAccounts) {
  const data = {
      purchaseConversionValue: 0,
      // Other variables
  };

  adAccounts.forEach((adAccount) => {
      const actions = adAccount.actions || [];

      const purchase = actions.find(
          (action) => action.action_type === 'offsite_conversion.fb_pixel_purchase'
      );

      if (purchase) {
          data.purchaseConversionValue += parseFloat(purchase.value);
      }
      // Other conditions to process other data
  });

  // Call the updateDashboardCards() function
  updateDashboardCards(data);
}

function updateDashboardCards(data) {
  // Update the "Earnings (Monthly)" card with the fetched data
  document.getElementById('monthly-earnings').innerHTML = '$' + data.purchaseConversionValue.toFixed(2);
}

// ...

document.addEventListener('DOMContentLoaded', () => {
  const facebookLoginButton = document.getElementById('facebook-login');
  if (facebookLoginButton) {
    facebookLoginButton.addEventListener('click', facebookLogin);
  } else {
    console.error('Facebook Login button not found');
  }
});

// ...


function fetchAdAccountData(accountId) {
  const fields = [
    'account_id',
    'account_name',
    'spend',
    'actions{action_type,value}',
    'outbound_clicks',
    'cost_per_outbound_click',
    'impressions',
    'clicks',
    'ctr',
  ].join(',');

  const date_preset = 'last_90d';
  const level = 'account';
  const accessToken = FB.getAuthResponse()['accessToken'];

  FB.api(
    `/v16.0/${accountId}/insights?fields=${fields}&date_preset=${date_preset}&level=${level}&access_token=${accessToken}`,
    'GET',
    {},
    function (response) {
      if (response && !response.error) {
        console.log(response);
        processData(response);
      } else {
        console.error(response.error);
      }
    }
  );
}


function displayError(message) {
  const errorContainer = document.createElement('div');
  errorContainer.className = 'error-message';
  errorContainer.textContent = message;

  // Append the error container to the body
  document.body.appendChild(errorContainer);

  // Remove the error container after 5 seconds
  setTimeout(() => {
    errorContainer.remove();
  }, 5000);
}

